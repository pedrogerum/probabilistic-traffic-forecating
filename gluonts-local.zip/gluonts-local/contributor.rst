Contributors
============

We would like to express our thanks to our awesome `GluonTS contributors <https://github.com/awslabs/gluon-ts/graphs/contributors>`__.

- `Alexander Alexandrov <https://github.com/aalexandrov>`__
- `Konstantinos Benidis <https://github.com/benidis>`__
- `Michael Bohlke-Schneider <https://github.com/mbohlkeschneider>`__
- `Laurent Callot <https://github.com/lcallot>`__
- `Vincent Deuschle <https://github.com/vdeuschle>`__
- `Valentin Flunkert <https://github.com/vafl>`__
- `Jan Gasthaus <https://github.com/jgasthaus>`__
- `Tim Januschowski <https://github.com/timoschowski>`__
- `Danielle Maddix <https://github.com/dcmaddix>`__
- `Roberto Medico <https://github.com/rmedico>`__
- `Syama Sundar Rangapuram <https://github.com/rshyamsundar>`__
- `Quentin Rebjock <https://github.com/SSappy>`__
- `David Salinas <https://github.com/geoalgo>`__
- `Jasper Schulz <https://github.com/jaheba>`__
- `Sergey Sokolov <https://github.com/Ishitori>`__
- `Lorenzo Stella <https://github.com/lostella>`__
- `Bernie Wang <https://github.com/lovvge>`__
- `Sheng Zha <https://github.com/szha>`__

.. note::

   The contributors are ordered by last name alphabetical order.

Interested in joining us? Check out our `contributing guide
<http://gluon-ts.mxnet.io/master/how_to/contribute.html>`__.
