This folder should contain the following files:

- calendar.csv
- sales_train_evaluation.csv
- sample_submission.csv
- sell_prices.csv

These can be found in the M5 competition repo.